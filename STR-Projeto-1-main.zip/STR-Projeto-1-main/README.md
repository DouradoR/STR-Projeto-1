Simulação de cruzamento de trilhos de trem
Projeto 1 - Grupo 6 
            Douglas Almeida
            Lucas Dantas
            Roberto Vasconcelos
